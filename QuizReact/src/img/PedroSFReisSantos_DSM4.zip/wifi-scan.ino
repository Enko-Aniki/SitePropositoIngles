#include <WiFi.h>
#include <DHT.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

#define DHTPIN 15
#define DHTTYPE DHT22
#define LDR_PIN 34

DHT dht(DHTPIN, DHTTYPE);

unsigned long lastSend = 0;
const long interval = 2000;

void conectarWiFi() {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi conectado");
}

void lerSensores(float &t, float &u, int &l) {
  t = dht.readTemperature();
  u = dht.readHumidity();
  l = 4095 - analogRead(LDR_PIN);
}

void exibir(float t, float u, int l) {
  Serial.println("---- DADOS ----");
  Serial.print("Temp: ");
  Serial.println(t);
  Serial.print("Umidade: ");
  Serial.println(u);
  Serial.print("Luminosidade: ");
  Serial.println(l);
}

void alertas(float t, float u, int l) {
  if (t > 30) Serial.println("ALERTA: alta temperatura");
  else if (t < 10) Serial.println("ALERTA: baixa temperatura");

  if (u < 40) Serial.println("ALERTA: baixa umidade");

  if (l < 1200) Serial.println("Ambiente escuro");
  else if (l < 3000) Serial.println("Ambiente iluminado");
  else Serial.println("Ambiente muito claro");
}

String gerarJSON(float t, float u, int l) {
  String json = "{";
  json += "\"temperatura\":";
  json += t;
  json += ",";
  json += "\"umidade\":";
  json += u;
  json += ",";
  json += "\"luminosidade\":";
  json += l;
  json += "}";
  return json;
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  conectarWiFi();
}

void loop() {
  if (millis() - lastSend >= interval) {
    lastSend = millis();

    float t, u;
    int l;

    lerSensores(t, u, l);
    exibir(t, u, l);
    alertas(t, u, l);

    String payload = gerarJSON(t, u, l);
    Serial.println("CoAP:");
    Serial.println(payload);
  }
}